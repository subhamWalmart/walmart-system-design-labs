# RetailOrderHub — Microservices Decomposition (Day 4/5)

This is the Day 2 monolith (`retailorderhub`, one Spring Boot app) split into
three business-capability services plus a Spring Cloud Gateway API gateway
to front them. It's the hands-on version of Day 4's Decomposition Pattern,
Database-per-Service, and Communication Pattern slides, using the same
RetailOrderHub case study and the same code you already reviewed on Day 2.

Service discovery is Kubernetes-native — each service reaches another
through a plain URL that resolves differently depending on where you're
running (`localhost` locally, a Docker Compose service name in a container,
a Kubernetes Service DNS name in a cluster) — rather than a self-hosted
Eureka registry. See "Dropping Eureka for Kubernetes-native discovery"
below for the reasoning; `reference/eureka-server-option-a/` keeps the
earlier Eureka-based version around for comparison.

## Architecture

```
                        ┌──────────────────┐
                        │    frontend       │  :5500 (static site)
                        │ (plain HTML/JS)   │
                        └─────────┬─────────┘
                                  │ fetch()
                                  ▼
                        ┌──────────────────┐
                        │   api-gateway     │  :8080
                        │ (Spring Cloud     │  <- one address for the
                        │  Gateway)         │     outside world
                        └─────────┬─────────┘
                                  │ routes by path
              ┌───────────────────┼───────────────────┐
              ▼                   ▼                   ▼
     ┌─────────────────┐ ┌──────────────────┐ ┌──────────────────┐
     │  order-service   │ │ inventory-service │ │ payment-service   │
     │  :8081           │ │ :8082             │ │ :8083             │
     │  orderdb (H2)     │ │ inventorydb (H2)   │ │ (no database)     │
     └────────┬─────────┘ └──────────────────┘ └──────────────────┘
              │  Feign, via a plain URL (localhost / Compose /
              │  Kubernetes Service name, depending where this runs)
              ├───────────────────────────┐
              ▼                           ▼
     inventory-service              payment-service
```

No registry box anymore — `order-service`'s two Feign clients and
`api-gateway`'s three routes each just point at a URL, sourced from an
environment variable with a `localhost` fallback. What resolves that URL
to a real address differs by environment (nothing, one instance, in a
local run; Docker's embedded DNS in Compose; a Kubernetes Service's
cluster DNS and load-balancing across pods, in a cluster) — but the
*application* code and config shape stay identical across all three.

## From monolith to services — what moved where

| Monolith file | Now lives in |
| --- | --- |
| `model/Order.java`, `repository/OrderRepository.java` | `order-service` (unchanged) |
| `service/OrderService.java` | `order-service`, rewritten to call `InventoryClient`/`PaymentClient` (Feign) instead of injected `InventoryService`/`PaymentService` beans |
| `controller/OrderController.java` | `order-service`, now a `@RestController` (`POST /api/orders`, `GET /api/orders`) instead of a Thymeleaf `@Controller` |
| `model/Product.java`, `repository/ProductRepository.java` | `inventory-service` (unchanged) |
| `repository/InventoryRepository.java`, `repository/JpaInventoryRepository.java` | `inventory-service` (unchanged, **including the SQL injection** — see below) |
| `service/InventoryService.java` | `inventory-service` (unchanged) |
| — (new) | `inventory-service`'s `InventoryController` — `GET /api/inventory/products`, `GET /api/inventory/{item}/quantity`, `GET /api/inventory/{item}/in-stock`, `POST /api/inventory/{item}/decrement` |
| `service/PaymentService.java`, `PaymentStrategy.java` and all five strategy classes | `payment-service` (unchanged) |
| — (new) | `payment-service`'s `PaymentController` — `POST /api/payments/charge` |
| `data.sql` | `inventory-service` (unchanged — same five products) |
| `application.properties` | split three ways, one per service, each with its own `server.port` and its own `spring.datasource.url` |

Every carried-forward class kept its original public contract (method names,
parameters, return types) — the point of this exercise is the seam between
services, not a rewrite of the business logic.

## Patterns from Day 4, made concrete

- **Decomposition Pattern** — boundaries follow business capability (Order,
  Inventory, Payment), not a technical split like "web layer" vs. "data
  layer."
- **Database-per-Service** — `order-service` and `inventory-service` each
  have their own in-memory H2 instance (`orderdb`, `inventorydb`); neither
  can see the other's tables. `payment-service` has no database at all,
  because it doesn't need one.
- **Communication Pattern** — all inter-service calls here are synchronous
  REST (`order-service` → `inventory-service`, `order-service` →
  `payment-service`), via declarative Feign clients. There's no async/event
  path in this version — see "What this doesn't do yet" below.
- **Service Discovery** — Kubernetes-native, not a self-hosted registry.
  `order-service`'s Feign clients and `api-gateway`'s routes each read a
  URL from an environment variable (`INVENTORY_SERVICE_URL`,
  `PAYMENT_SERVICE_URL`, `ORDER_SERVICE_URL`), falling back to `localhost`
  when nothing overrides them. In Docker Compose that variable is set to a
  Compose service name; in Kubernetes it would be a Service DNS name,
  which the platform already load-balances across every healthy pod behind
  it. See "Dropping Eureka for Kubernetes-native discovery" below for why
  this isn't a self-hosted Eureka registry instead.
- **API Gateway** — `api-gateway` is the only address a client needs.
  `GET http://localhost:8080/api/orders` and
  `GET http://localhost:8081/api/orders` (hitting order-service directly)
  return the same thing today, but only the gateway address is meant to be
  public.

## Dropping Eureka for Kubernetes-native discovery

The first version of this decomposition used a self-hosted Eureka registry
(`eureka-server`, still kept as `reference/eureka-server-option-a/` for
comparison) — every service registered itself there on startup, and Feign
clients / the gateway's `lb://` routes asked it "where is inventory-service
right now?" at call time.

Once AKS is the actual target, that stops earning its keep: Kubernetes
already does the two jobs Eureka was doing here — give a service a stable
name (a Service's DNS entry), and load-balance across however many
instances of it are currently healthy (a Service load-balances across
every Ready pod behind it automatically). Running Eureka *on top of*
Kubernetes means paying for that twice — a second registry, a second
health-check mechanism, a second thing that can fall over — for
functionality the platform underneath already provides for free.

What changed to drop it:

- **Four `pom.xml` files** (`api-gateway`, `order-service`,
  `inventory-service`, `payment-service`) — removed
  `spring-cloud-starter-netflix-eureka-client`. `spring-cloud-starter-openfeign`
  stays on `order-service`; Feign itself has nothing to do with Eureka,
  it's just the HTTP client abstraction.
- **`InventoryClient` and `PaymentClient`** (`order-service`'s two Feign
  clients) — `@FeignClient(name = "inventory-service")`, which used to mean
  "resolve this name via Eureka", now carries an explicit
  `url = "${inventory.service.url}"`. That property is itself
  `${INVENTORY_SERVICE_URL:http://localhost:8082}` in
  `application.properties` — an environment-variable override with a
  `localhost` fallback, the exact same pattern the earlier Docker work
  already used for `EUREKA_URI`.
- **`api-gateway`'s routes** — `uri: lb://order-service` (Eureka-resolved,
  client-side load-balanced) became `uri: ${ORDER_SERVICE_URL:http://localhost:8081}`
  (and the same shape for the other two routes). No `lb://` scheme left
  anywhere in this project.
- **Every `eureka.client.*` / `eureka.instance.*` property** — deleted from
  all four `application.properties`/`.yml` files. Nothing replaces them;
  there's no "register yourself" step with Kubernetes-native discovery.
- **`docker-compose.yml`** — no `eureka-server` entry. `inventory-service`
  and `payment-service` no longer depend on anything and can start
  immediately (a small side benefit — the old version had every single
  service waiting on Eureka first). `order-service` and `api-gateway` get
  their `*_SERVICE_URL` environment variables set to Compose service names
  instead of an `EUREKA_URI`.

Why this was worth doing *before* writing Kubernetes manifests, not after:
the property names (`INVENTORY_SERVICE_URL`, `PAYMENT_SERVICE_URL`,
`ORDER_SERVICE_URL`) and the shape of the values (`http://<name>:<port>`)
carry straight into a Kubernetes ConfigMap unchanged — just point them at
Service names instead of Compose service names. "How do services find each
other" is a solved, already-tested problem by the time the manifests get
written; the manifests are just wiring up names.

## What's intentionally still broken

Two Day 1/2 findings were carried forward on purpose and are **not** fixed by
this decomposition:

- **SQL injection** in `inventory-service`'s `JpaInventoryRepository` — both
  native queries are still built by string concatenation. Splitting this
  into its own service doesn't fix it, and arguably makes it more exposed:
  `itemName` now arrives over a REST path variable
  (`/api/inventory/{itemName}/quantity`), reachable by anything that can
  reach this service, not just code inside the same JVM.
- **TOCTOU race** in `order-service`'s `OrderService.processOrder()` — stock
  is still checked in one loop and decremented in a separate later loop,
  with payment in between. This is a *sharper* problem now than it was in
  the monolith: it used to be one `@Transactional` method against one
  database; now it's three separate network calls against two other
  services' own databases, with no rollback if something fails partway
  through or two orders race for the same last unit of stock.

If you're using this as an answer key, don't quietly patch either of these —
they're meant to stay open findings for later discussion (see "Next steps").

## A real bug the decomposition introduced (now fixed)

Unlike the two findings above, this one was never in the monolith — it's a
regression the decomposition itself caused, and worth walking through if it
comes up in a session:

`JpaInventoryRepository.decrementQuantity()` runs a native `UPDATE` via
`entityManager.createNativeQuery(...).executeUpdate()`. JPA requires an
active transaction for any write, or it throws
`jakarta.persistence.TransactionRequiredException`. In the monolith this
worked without anyone writing a line of transaction-handling code for it,
because it ran inside `OrderService.processOrder()`, which *was*
`@Transactional` — that transaction propagated across the in-process method
calls into `InventoryService` and down into the repository. Once
`inventory-service` became its own process, that borrowed transaction was
gone, and nothing about calling this service over HTTP created a new one.
`getQuantity()` (a plain `SELECT`) never needed a transaction, which is why
the stock check earlier in `processOrder()` succeeds and only the decrement
call fails, with a 500 surfacing on the `order-service` side as a
`FeignException$InternalServerError`.

Fixed by adding `@Transactional` to `InventoryService.decrementQuantity()`
— see the comment there. The general lesson: decomposing a monolith doesn't
just relocate code, it can strip away transactional (or security, or
validation) context that calling code was silently relying on. Each service
has to establish its own instead of inheriting the caller's by accident.

## What changed instead of being carried forward

- **The Thymeleaf UI is gone, replaced by `frontend/`.** The monolith's
  `index.html` (catalog + order form) and `orders.html` (order list)
  depended on `ProductRepository` and `OrderRepository` being in the same
  process as the controller rendering the page. Once those repositories
  moved to different services, that stopped being possible without a
  server-side aggregation layer. `frontend/` is a plain HTML/CSS/JS static
  site — no framework, no build step — that calls `api-gateway` the same
  way any other client would, and covers the same three things the old
  pages did: browse the catalog, place an order, see the order list. See
  `frontend/README.md` for how to run it (and why `api-gateway`'s
  `application.yml` now has a CORS block).
- **`OrderService.processOrder()` returns the `Order`, not a `boolean`** —
  needed so `OrderController` can hand back the new order's ID in
  `OrderResponse`. The monolith's version only ever returned success/failure.

## Running it

Requires JDK 17 and Maven. Build everything once from the repo root:

```
cd retailorderhub-microservices
mvn clean install
```

Then start each service in its own terminal, **in this order** — the two
services with no dependencies on each other first, then order-service
(which needs both of them reachable), then the gateway last:

```
cd inventory-service     && mvn spring-boot:run   # 1. )
cd payment-service       && mvn spring-boot:run   # 1. ) any order, both independent
cd order-service         && mvn spring-boot:run   # 2. needs 1 reachable on localhost:8082/8083
cd api-gateway            && mvn spring-boot:run   # 3. needs 2 reachable on localhost:8081 (and 1)
```

Give each service a few seconds to finish starting before starting the next
one that depends on it - there's no registry to check readiness against
anymore, just watch each terminal for Spring Boot's "Started
<Service>Application" line.

Then, optionally, serve the frontend (see `frontend/README.md`):

```
cd frontend
python3 -m http.server 5500   # 4. static site, talks to the gateway on :8080
```

Open **http://localhost:5500**.

## Running it in Docker

Same four services plus the frontend, containerized, orchestrated with
`docker-compose.yml`. Requires Docker and Docker Compose (Docker Desktop
gives you both). Still requires the jars to exist first — Docker packages
the *already-built* artifact rather than running Maven inside the image
(see "Why the jars are built outside Docker" below):

```
cd retailorderhub-microservices
mvn clean install
docker compose up --build
```

That's the whole run order problem from the local instructions above,
solved: every service's `docker-compose.yml` entry has a `healthcheck`
(pings its own `/actuator/health`) and `depends_on: ... condition:
service_healthy`, so Compose won't start `order-service`'s container until
`inventory-service` and `payment-service` both report healthy — not just
"the container started", which is Compose's weaker default meaning of
`depends_on`. No manual waiting between steps.

All the same ports as running locally, so the curl commands and the
frontend below both work unmodified: gateway on **:8080**, frontend on
**:5500** (containerized too, via nginx).

```
docker compose down          # stop and remove the containers
docker compose down -v       # same, plus remove the network
```

### What had to change for this to work

- **`localhost` → environment-variable-driven URLs.** Every service that
  calls another one - `order-service` (via its two Feign clients) and
  `api-gateway` (via its routes) - falls back to `localhost` when nothing
  overrides it, and gets a Compose service name instead
  (`INVENTORY_SERVICE_URL: http://inventory-service:8082`, etc.) via the
  `environment:` block in `docker-compose.yml`. This is the same pattern
  used for Kubernetes-native discovery in general (see "Dropping Eureka for
  Kubernetes-native discovery" above) - Docker Compose's per-network DNS
  and Kubernetes' cluster DNS both resolve a service's name to its current
  address, so the exact same environment-variable names carry into a
  Kubernetes ConfigMap unchanged, just pointed at Service names instead of
  Compose service names.
- **A `Dockerfile` per service** — four nearly-identical ones, each just
  `FROM eclipse-temurin:17-jre-alpine`, `COPY target/<service>.jar
  app.jar`, `EXPOSE <port>`, `ENTRYPOINT java -jar app.jar`. The frontend's
  is different: `FROM nginx:alpine`, copy the three static files in.
  Nothing in any service's actual Java code changed to make it
  containerizable — a Spring Boot jar is already a self-contained,
  runnable artifact; Docker is just packaging it with a JVM.
- **`api-gateway`'s CORS config didn't need to change.** It already allows
  all origins (`allowedOrigins: "*"`, added when the frontend was first
  built) - that's origin-based, not container-network-based, so it doesn't
  care whether the frontend is a `python3 -m http.server` process or an
  nginx container.
- **The frontend's `app.js` didn't need to change either.** It calls
  whatever's in the gateway URL field (default `http://localhost:8080`),
  and that call happens in the *browser*, never inside the Docker network
  - so it's always talking to the gateway's published host port, exactly
  like it was before containerizing anything.

### Why the jars are built outside Docker

This project is a multi-module Maven reactor - every service's `pom.xml`
has `<parent>com.training:retailorderhub-microservices</parent>`, which
only resolves from the root `pom.xml`. A Dockerfile whose build context is
just `order-service/` can't see that root pom, so a naive `mvn package`
*inside* that Dockerfile would fail. There are two ways around that:

1. **(What's here)** Build all four jars locally first
   (`mvn clean install`, which you already need to do for the non-Docker
   path), then each `Dockerfile` just copies its own pre-built jar. Simple,
   and keeps every Dockerfile nearly identical - but the image build isn't
   self-contained; whoever runs `docker compose up --build` needs Maven
   and a JDK on their machine first, which somewhat defeats one of Docker's
   usual selling points.
2. **Multi-stage builds from the repo root** - set each service's Docker
   build *context* to the repository root (not the service subdirectory),
   `COPY` the whole reactor into a build stage, run
   `mvn -pl <service> -am clean package` (`-am` pulls in the parent and any
   depended-on modules), then copy just the resulting jar into a slim
   runtime stage. Fully reproducible from source with nothing but Docker
   installed, at the cost of a slower, more repetitive Dockerfile per
   service and a larger build context sent to the Docker daemon each time.

Option 1 is what's implemented, since it matches the `mvn clean install`
step already documented in "Running it" above and keeps the Docker layer
small and easy to read for a training exercise. Option 2 is the better
choice for an actual CI/CD pipeline - worth calling out as a live exercise
if a session wants to go further than this repo does.

### What Docker does *not* fix

Every service's H2 database is still in-memory
(`spring.jpa.hibernate.ddl-auto=create-drop`) - containerizing it doesn't
add persistence. `docker compose down` (or a plain container restart)
wipes `orderdb` and `inventorydb` exactly the way stopping the local
`mvn spring-boot:run` process always did. If you want data to survive a
restart, that's a real infrastructure change (an external MySQL/PostgreSQL
container with a mounted volume, one per service to keep Database-per-
-Service honest), not something implied by containerizing - a natural
Day 5 / Kubernetes-adjacent follow-up, not done here.

## Try it end-to-end

Works identically whether you started everything locally or with
`docker compose up` - same ports either way. All of these go through the
gateway on :8080. (Swap in :8081/:8082/:8083 to call a service directly and
skip the gateway, if you want to show that difference live.)

```bash
# Catalog - should list Laptop, Mouse, Keyboard, Monitor, Headphones
curl http://localhost:8080/api/inventory/products

# Place an order
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -d '{
        "customerId": "CUST-001",
        "itemNames": ["Laptop", "Mouse"],
        "paymentMethod": "CREDIT_CARD",
        "amount": 1019.98
      }'

# List orders
curl http://localhost:8080/api/orders

# Confirm stock actually decremented
curl http://localhost:8080/api/inventory/Laptop/quantity

# Try an unknown payment method - should fail cleanly, no order created
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -d '{"customerId":"CUST-002","itemNames":["Mouse"],"paymentMethod":"BITCOIN","amount":19.99}'
```

## Running it on Kubernetes (AKS)

The `k8s/` folder has a Deployment + Service per backend service, a
ConfigMap holding the same `*_SERVICE_URL` values used in Docker Compose
(now pointed at Kubernetes Service DNS names instead of Compose service
names), and readiness/liveness probes wired to `/actuator/health/readiness`
and `/actuator/health/liveness`. `api-gateway` and `frontend` are exposed
as `LoadBalancer` Services so AKS hands each one a public IP directly — no
Ingress controller needed for this lab. Full step-by-step deployment
instructions (building images, pushing to ACR, applying the manifests) are
in the separate AKS lab guide, not repeated here.

### Chaos / self-healing demo

`inventory-service` has one training-only addition, `ChaosController`
(`POST /chaos/break`), that flips its Spring Boot liveness state to
`BROKEN`. `management.endpoint.health.probes.enabled=true` (added to all
four backend services' config) is what makes Actuator expose that as
`GET /actuator/health/liveness` in the first place, and the Deployment's
`livenessProbe` in `k8s/10-inventory-service.yaml` polls exactly that URL
every 5 seconds. Three failures in a row and kubelet kills and restarts the
container — no human intervention, no code change needed to recover. The
fresh container starts with liveness `CORRECT` again. `POST /chaos/fix`
exists only so an instructor can cancel the demo early without waiting for
the restart. This is a demo aid, not a pattern to copy into a real service.

## Next steps (not built here)

- **Saga Pattern** for `processOrder()` — today's version has no
  compensating transaction if payment succeeds but the later decrement
  calls fail, or if inventory changes between the check and the charge.
  This is exactly the scenario Day 4's Saga Pattern slide walks through
  (reserve stock → charge → confirm, with compensating steps on failure) —
  a natural follow-on lab against this exact code.
- **Resilience** on the Feign calls — Day 3 covered the Circuit Breaker
  pattern; none of these Feign clients have one yet, so a slow or down
  inventory-service currently just makes `order-service` wait (bounded by
  the timeouts in `order-service`'s `application.properties`) rather than
  failing fast or falling back.
- **API Gateway cross-cutting concerns** — auth, rate limiting, and request
  logging would normally live in `api-gateway` rather than in each service;
  none are configured here.
