package com.training.retailorderhub.orderservice.client;

import com.training.retailorderhub.orderservice.dto.InventoryQuantityResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * TRAINING NOTE (Day 4 - Communication Pattern; Option B - Kubernetes-native
 * discovery, no Eureka):
 * "name" is just a label Feign/Spring Cloud use internally (for metrics,
 * circuit-breaker config keys, etc.) - it no longer means "look this up in
 * a registry". "url" is what actually gets called, and it comes from
 * inventory.service.url in application.properties, which defaults to
 * http://localhost:8082 for local runs and gets overridden to
 * http://inventory-service:8082 in Docker Compose or Kubernetes (a
 * Kubernetes Service name resolves via cluster DNS to whichever pod
 * replicas are currently healthy - the load-balancing job Eureka +
 * LoadBalancer used to do here, now done by the platform).
 *
 * This interface has no implementation in this codebase - Feign generates
 * one at startup from the method signatures and annotations below.
 */
@FeignClient(name = "inventory-service", url = "${inventory.service.url}")
public interface InventoryClient {

    @GetMapping("/api/inventory/{itemName}/quantity")
    InventoryQuantityResponse getQuantity(@PathVariable("itemName") String itemName);

    @PostMapping("/api/inventory/{itemName}/decrement")
    void decrement(@PathVariable("itemName") String itemName);
}
