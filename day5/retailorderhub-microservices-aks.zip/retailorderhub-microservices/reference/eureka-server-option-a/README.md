# eureka-server (Option A - not used)

This is the Eureka registry from before the project switched to
Kubernetes-native service discovery. It's kept here only as a reference for
what "Option A" (self-hosted Eureka registry) looked like, in case that
comparison is useful in a session.

**It is not part of the active build** - it's excluded from the root
`pom.xml`'s `<modules>` list, and `docker-compose.yml` no longer has an
`eureka-server` entry. None of the other four services reference it either
- see the root README's "Dropping Eureka for Kubernetes-native discovery"
section for the full before/after.

If you want to actually run this version again: add `<module>reference/eureka-server-option-a</module>`
back to the root `pom.xml`, and reintroduce the `spring-cloud-starter-netflix-eureka-client`
dependency plus the `eureka.client.*` properties into `api-gateway`,
`order-service`, `inventory-service`, and `payment-service`. Easiest to
just pull those from git history if this repo is under version control.
