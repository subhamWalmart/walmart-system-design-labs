package com.training.retailorderhub.inventoryservice.controller;

import org.springframework.boot.availability.AvailabilityChangeEvent;
import org.springframework.boot.availability.LivenessState;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * TRAINING NOTE (Day 5 - Kubernetes Self-Healing Demo):
 * This controller exists purely to let the training session trigger a
 * controlled failure - it is not something a real service would ship.
 *
 * POST /chaos/break flips this instance's Spring Boot liveness state to
 * BROKEN. Spring Boot Actuator already exposes that as
 * GET /actuator/health/liveness (see management.endpoint.health.probes.enabled=true
 * in application.properties). The Kubernetes Deployment's livenessProbe
 * polls that exact URL - once it fails enough times in a row, kubelet kills
 * the container and restarts it. The fresh container starts with liveness
 * CORRECT again, so the pod heals itself with no human intervention.
 *
 * POST /chaos/fix flips it back without waiting for a restart, in case an
 * instructor needs to cancel the demo early.
 *
 * Nothing else in the service is affected - the app keeps handling normal
 * /api/inventory/** requests right up until Kubernetes restarts the pod.
 */
@RestController
@RequestMapping("/chaos")
public class ChaosController {

    private final ApplicationEventPublisher publisher;

    public ChaosController(ApplicationEventPublisher publisher) {
        this.publisher = publisher;
    }

    @PostMapping("/break")
    public String breakLiveness() {
        AvailabilityChangeEvent.publish(publisher, this, LivenessState.BROKEN);
        return "inventory-service liveness set to BROKEN. Kubernetes should restart this pod shortly.";
    }

    @PostMapping("/fix")
    public String fixLiveness() {
        AvailabilityChangeEvent.publish(publisher, this, LivenessState.CORRECT);
        return "inventory-service liveness set back to CORRECT.";
    }
}
