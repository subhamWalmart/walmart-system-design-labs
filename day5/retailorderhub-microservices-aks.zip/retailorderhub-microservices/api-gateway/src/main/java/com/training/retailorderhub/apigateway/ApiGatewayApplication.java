package com.training.retailorderhub.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * TRAINING NOTE (Day 4/5 - API Gateway; Option B - Kubernetes-native
 * discovery, no Eureka):
 * No custom code needed here - the routing rules live entirely in
 * application.yml. Each route's URI is a plain URL (env-var driven, see the
 * TRAINING NOTE there) rather than an "lb://<service-name>" address Eureka
 * would have resolved - in Kubernetes that URL is a Service DNS name, which
 * the platform already load-balances across every healthy pod behind it.
 *
 * This is the one address the outside world (or a future UI) needs to know:
 * http://localhost:8080. Everything behind it - which service owns which
 * path, how many instances of it are running, where they currently are - is
 * this gateway's problem, not the caller's.
 */
@SpringBootApplication
public class ApiGatewayApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
